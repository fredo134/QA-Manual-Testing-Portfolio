/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 77.33333333333333, "KoPercent": 22.666666666666668};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.63, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.1, 500, 1500, "01 - post Auth"], "isController": false}, {"data": [0.91, 500, 1500, "02 - POST Create Booking"], "isController": false}, {"data": [0.88, 500, 1500, "03 - PUT Update Booking"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 150, 34, 22.666666666666668, 2144.433333333333, 249, 18359, 433.0, 7281.200000000002, 10541.949999999995, 16005.860000000042, 4.507211538461538, 3.8492642916165862, 1.8112769493689904], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["01 - post Auth", 50, 29, 58.0, 5187.7, 1100, 18359, 3888.0, 11282.699999999999, 13086.099999999995, 18359.0, 1.5449741989308778, 1.16295518802336, 0.4179275909217316], "isController": false}, {"data": ["02 - POST Create Booking", 50, 3, 6.0, 869.24, 261, 12748, 342.0, 1081.8999999999994, 6413.45, 12748.0, 1.6424676433874252, 1.5106852785625122, 0.737827261677945], "isController": false}, {"data": ["03 - PUT Update Booking", 50, 2, 4.0, 376.36, 249, 587, 347.0, 514.6, 575.65, 587.0, 2.059308072487644, 1.8318993255766063, 1.0005341330313013], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 5,526 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 6,390 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 12,547 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 10,812 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 7,588 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["403/Forbidden", 2, 5.882352941176471, 1.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 4,978 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 18,359 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 5,195 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 4,365 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 9,612 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 13,745 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 4,590 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 6,413 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 4,004 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 12,748 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 5,803 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 3,772 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 8,026 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 7,312 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 6,124 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 11,335 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 3,402 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 6,414 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 9,151 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 3,497 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 7,004 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 3,213 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 6,794 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 8,549 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 8,980 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 12,131 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 10,321 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 2.9411764705882355, 0.6666666666666666], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 150, 34, "403/Forbidden", 2, "The operation lasted too long: It took 5,526 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 6,390 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 12,547 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 10,812 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["01 - post Auth", 50, 29, "The operation lasted too long: It took 5,526 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 6,390 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 12,547 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 10,812 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 7,588 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1], "isController": false}, {"data": ["02 - POST Create Booking", 50, 3, "The operation lasted too long: It took 6,414 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 6,413 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 12,748 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "", "", "", ""], "isController": false}, {"data": ["03 - PUT Update Booking", 50, 2, "403/Forbidden", 2, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
