/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.33333333333333, "KoPercent": 5.666666666666667};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.79, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.39, 500, 1500, "01 - post Auth"], "isController": false}, {"data": [1.0, 500, 1500, "02 - POST Create Booking"], "isController": false}, {"data": [0.98, 500, 1500, "03 - PUT Update Booking"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 300, 17, 5.666666666666667, 814.1399999999994, 247, 6321, 305.0, 1231.9, 3203.8999999999996, 6193.95, 9.622478108862303, 8.23307621604067, 3.8681923473233475], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["01 - post Auth", 100, 15, 15.0, 1755.56, 1055, 6321, 1180.5, 4167.8, 5210.3, 6319.999999999999, 3.2675467259181805, 2.4598500196052804, 0.8838969170696641], "isController": false}, {"data": ["02 - POST Create Booking", 100, 0, 0.0, 291.54, 247, 378, 293.5, 307.0, 310.9, 377.3599999999997, 3.5380696292103027, 3.256717080473394, 1.5893672162468158], "isController": false}, {"data": ["03 - PUT Update Booking", 100, 2, 2.0, 395.3199999999998, 255, 5387, 298.0, 307.0, 316.95, 5386.009999999999, 3.543586109142452, 3.1663187677179305, 1.7231033509036144], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 6,221 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 6,321 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["403/Forbidden", 2, 11.764705882352942, 0.6666666666666666], "isController": false}, {"data": ["The operation lasted too long: It took 5,157 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 4,148 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 5,197 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 4,180 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 3,144 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 4,211 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 5,211 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 3,211 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 3,205 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 6,189 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 4,170 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 6,194 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}, {"data": ["The operation lasted too long: It took 3,183 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, 5.882352941176471, 0.3333333333333333], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 300, 17, "403/Forbidden", 2, "The operation lasted too long: It took 6,221 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 6,321 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 5,157 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 4,148 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["01 - post Auth", 100, 15, "The operation lasted too long: It took 6,221 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 6,321 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 5,157 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 4,148 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1, "The operation lasted too long: It took 5,197 milliseconds, but should not have lasted longer than 3,000 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": ["03 - PUT Update Booking", 100, 2, "403/Forbidden", 2, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
